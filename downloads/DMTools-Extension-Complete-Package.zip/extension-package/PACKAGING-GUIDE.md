# 📦 Chrome Extension Packaging Guide

## Quick Start

### For Mac/Linux:
```bash
./package-extension.sh
```

### For Windows:
```bash
package-extension.bat
```

---

## 📋 What Gets Packaged

The packaging script includes **ONLY** these files:

✅ **Included:**
- `manifest.json` - Extension configuration
- `background.js` - Service worker
- `content.js` - Page injection script
- `popup.html` - Extension popup UI
- `popup.js` - Popup functionality
- `popup.css` - Popup styling
- `icons/` - All extension icons

❌ **Excluded:**
- `server.js` - Backend server (not part of extension)
- `pwa-manifest.json` - Website PWA manifest
- `background_-_Copy.js` - Backup files
- All HTML files (app.html, pricing.html, etc.)
- Any temporary or build files
- Documentation files

---

## 🎯 Output

**Location:** `./dist/dmtools-chrome-extension-v1.0.0.zip`

**Size:** ~17KB (compressed)

**Contents:** 10 files (7 files + 3 icons)

---

## 🧪 Testing Before Upload

### Local Testing (Chrome):

1. **Open Extensions Page:**
   - Navigate to `chrome://extensions`
   - Or: Menu → More Tools → Extensions

2. **Enable Developer Mode:**
   - Toggle the "Developer mode" switch in the top-right corner

3. **Load Unpacked Extension:**
   - Click "Load unpacked"
   - Select the `/mnt/project/` folder (NOT the zip file)
   - The extension should appear in your extensions list

4. **Test Core Features:**
   - [ ] Extension icon appears in toolbar
   - [ ] Clicking icon opens popup
   - [ ] Can log in with DMTools account
   - [ ] Right-click context menus appear ("Capture Message", "Generate Reply")
   - [ ] Message capture works on test pages
   - [ ] AI response generation works

### Test on Real Platforms:

- [ ] Gmail (mail.google.com)
- [ ] LinkedIn (linkedin.com)
- [ ] Twitter/X (twitter.com or x.com)
- [ ] Outlook (outlook.live.com)
- [ ] Instagram (instagram.com)

---

## 🚀 Chrome Web Store Submission

### Prerequisites:

1. **Chrome Web Store Developer Account**
   - Cost: $5 one-time registration fee
   - Register at: https://chrome.google.com/webstore/devconsole

2. **Required Materials:**
   - Extension ZIP file (created by packaging script)
   - Screenshots (1280x800 or 640x400)
   - Promotional images (440x280 small tile)
   - Extension description
   - Privacy policy URL

### Submission Steps:

1. **Go to Developer Dashboard:**
   ```
   https://chrome.google.com/webstore/devconsole
   ```

2. **Create New Item:**
   - Click "New Item" button
   - Upload: `dist/dmtools-chrome-extension-v1.0.0.zip`
   - Wait for upload to complete

3. **Fill Out Store Listing:**
   
   **Product Details:**
   - Name: `DMTools - AI Reply Assistant`
   - Summary: `Generate AI-powered replies to messages across all platforms - Premium Feature`
   - Category: `Productivity`
   - Language: `English`

   **Detailed Description:**
   ```
   DMTools is your AI-powered assistant for generating professional replies to messages across all platforms.

   ✨ KEY FEATURES:
   • Right-click context menu integration
   • AI-powered response generation
   • Works on Gmail, LinkedIn, Twitter, and more
   • Personalized tone settings
   • Supports Pro, Business, and Enterprise plans

   🚀 HOW TO USE:
   1. Select incoming message text
   2. Right-click → "Capture Message with DMTools"
   3. Click in reply field
   4. Right-click → "Generate Reply with DMTools"
   5. AI response appears instantly!

   🔒 PRIVACY & SECURITY:
   • Secure authentication
   • No data stored locally
   • Messages processed through encrypted connection
   • Requires DMTools.fun account

   📧 SUPPORT:
   Visit https://dmtools.fun or email support@dmtools.fun
   ```

   **Privacy Policy URL:**
   ```
   https://dmtools.fun/privacy-policy.html
   ```

4. **Upload Assets:**
   - Screenshots (minimum 1, maximum 5)
   - Small promotional tile (440x280)
   - Marquee promotional tile (1400x560) - optional

5. **Set Visibility:**
   - Choose "Public" for general availability
   - Or "Unlisted" if you only want direct link distribution

6. **Submit for Review:**
   - Click "Submit for Review"
   - Review typically takes 1-3 business days
   - You'll receive email notification when approved

---

## 📝 Store Listing Best Practices

### Screenshots:
- Show the extension in action
- Include popup interface
- Show context menu
- Demonstrate AI response generation
- Add captions explaining each feature

### Promotional Images:
- Use your brand colors (purple gradient)
- Include "DM" logo
- Add text like "AI Reply Assistant"
- Keep it clean and professional

---

## 🔄 Updating the Extension

When you need to release an update:

1. **Update Version:**
   - Edit `manifest.json`
   - Change `"version": "1.0.0"` to `"version": "1.0.1"`

2. **Re-package:**
   ```bash
   ./package-extension.sh
   ```

3. **Upload to Chrome Web Store:**
   - Go to your extension in the dashboard
   - Click "Package" → "Upload new package"
   - Select the new ZIP file
   - Submit for review

---

## ❓ Troubleshooting

### "Could not load manifest" error:
- Make sure you're selecting the root folder, not a subfolder
- Verify `manifest.json` exists in the selected directory
- Check that manifest.json has valid JSON syntax

### Context menus don't appear:
- Refresh the webpage after installing extension
- Try disabling and re-enabling the extension
- Check that extension has required permissions

### "Invalid package" on Web Store:
- Verify ZIP contains only extension files
- Make sure no extra files are included
- Re-run the packaging script

### Icons don't show up:
- Verify icons folder exists in the package
- Check that all three icon sizes are present (16, 48, 128)
- Make sure icons are PNG format

---

## 📞 Support

- **Website:** https://dmtools.fun
- **Email:** support@dmtools.fun
- **Documentation:** See PROJECT-STRUCTURE.md

---

## ✅ Pre-Launch Checklist

Before submitting to Chrome Web Store:

- [ ] All code tested locally
- [ ] No console errors in background script
- [ ] Authentication flow works correctly
- [ ] Context menus appear properly
- [ ] AI generation works on test accounts
- [ ] Icons display correctly
- [ ] Popup interface functions properly
- [ ] Extension manifest is valid
- [ ] Privacy policy is accessible
- [ ] Screenshots prepared
- [ ] Store listing text written
- [ ] Version number is correct

**Once all boxes are checked, you're ready to launch! 🚀**
