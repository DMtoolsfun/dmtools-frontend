# DMTools.fun - Project Structure

## 📁 File Organization

### Chrome Extension Files
Located in root directory (for packaging):
- `manifest.json` - Chrome Extension manifest (Manifest V3)
- `background.js` - Extension service worker
- `content.js` - Content script for page injection
- `popup.html` - Extension popup interface
- `popup.js` - Popup functionality
- `popup.css` - Popup styling
- `icons/` - Extension icons (16x16, 48x48, 128x128)

### Web Application Files
- `pwa-manifest.json` - Progressive Web App manifest
- `server.js` - Backend API server
- `app.html` - Main web application
- All other HTML files (pricing.html, account.html, etc.)

## ⚠️ Important Notes

### Two Manifest Files
This project has **two separate manifest.json files**:

1. **`manifest.json`** (Root) - Chrome Extension
   - Used ONLY by the browser extension
   - Contains extension-specific permissions and scripts
   - Manifest Version 3

2. **`pwa-manifest.json`** - Progressive Web App
   - Used by the website for PWA functionality
   - Referenced in HTML files as `/pwa-manifest.json`
   - Contains app icons and display settings

### HTML Files Reference
All website HTML files should reference the PWA manifest like this:
```html
<link rel="manifest" href="/pwa-manifest.json">
```

### Chrome Extension Packaging
To package the extension, include ONLY these files:
- manifest.json (extension manifest)
- background.js
- content.js
- popup.html
- popup.js
- popup.css
- icons/ folder

DO NOT include:
- pwa-manifest.json
- server.js
- HTML files (app.html, pricing.html, etc.)
- Any website assets

## 🚀 Deployment

### Extension Deployment
1. Create `icons/` folder with required icon sizes
2. Zip the extension files listed above
3. Upload to Chrome Web Store

### Website Deployment
1. Deploy server.js to Railway/Heroku
2. Update HTML files to reference `/pwa-manifest.json`
3. Ensure PWA icons are in `/icons/` directory

## 📝 Pre-Launch Checklist

- [x] Fix urlLower typo in background.js
- [x] Separate extension and PWA manifests
- [ ] Create extension icons
- [ ] Remove backup file (background_-_Copy.js)
- [ ] Test extension on all platforms
- [ ] Update HTML files to use pwa-manifest.json
