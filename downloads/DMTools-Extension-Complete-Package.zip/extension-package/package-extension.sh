#!/bin/bash
# DMTools Chrome Extension Packaging Script
# This script creates a clean ZIP file ready for Chrome Web Store submission

set -e  # Exit on any error

# Colors for output
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo -e "${BLUE}========================================${NC}"
echo -e "${BLUE}  DMTools Chrome Extension Packager${NC}"
echo -e "${BLUE}========================================${NC}"
echo ""

# Configuration
EXTENSION_NAME="dmtools-chrome-extension"
VERSION=$(grep -oP '"version":\s*"\K[^"]+' manifest.json)
OUTPUT_DIR="./dist"
TEMP_DIR="./temp-extension-build"
ZIP_NAME="${EXTENSION_NAME}-v${VERSION}.zip"

# Files to include in the extension package
EXTENSION_FILES=(
    "manifest.json"
    "background.js"
    "content.js"
    "popup.html"
    "popup.js"
    "popup.css"
    "icons"
)

echo -e "${YELLOW}📦 Extension:${NC} ${EXTENSION_NAME}"
echo -e "${YELLOW}📌 Version:${NC} ${VERSION}"
echo ""

# Step 1: Clean up any previous builds
echo -e "${BLUE}[1/6]${NC} Cleaning up previous builds..."
rm -rf "$TEMP_DIR"
mkdir -p "$OUTPUT_DIR"

# Step 2: Create temporary build directory
echo -e "${BLUE}[2/6]${NC} Creating temporary build directory..."
mkdir -p "$TEMP_DIR"

# Step 3: Copy extension files
echo -e "${BLUE}[3/6]${NC} Copying extension files..."
for file in "${EXTENSION_FILES[@]}"; do
    if [ -e "$file" ]; then
        if [ -d "$file" ]; then
            echo "  ✓ Copying directory: $file"
            cp -r "$file" "$TEMP_DIR/"
        else
            echo "  ✓ Copying file: $file"
            cp "$file" "$TEMP_DIR/"
        fi
    else
        echo -e "  ${RED}✗ Warning: $file not found${NC}"
    fi
done

# Step 4: Verify manifest.json
echo -e "${BLUE}[4/6]${NC} Verifying manifest.json..."
if [ -f "$TEMP_DIR/manifest.json" ]; then
    # Check if it's a Chrome Extension manifest (has manifest_version)
    if grep -q '"manifest_version"' "$TEMP_DIR/manifest.json"; then
        echo "  ✓ Valid Chrome Extension manifest found"
    else
        echo -e "  ${RED}✗ Error: Invalid manifest - missing manifest_version${NC}"
        rm -rf "$TEMP_DIR"
        exit 1
    fi
else
    echo -e "  ${RED}✗ Error: manifest.json not found${NC}"
    rm -rf "$TEMP_DIR"
    exit 1
fi

# Step 5: Create ZIP file
echo -e "${BLUE}[5/6]${NC} Creating ZIP package..."
cd "$TEMP_DIR"
zip -r "../$OUTPUT_DIR/$ZIP_NAME" . -q
cd ..

if [ -f "$OUTPUT_DIR/$ZIP_NAME" ]; then
    FILE_SIZE=$(du -h "$OUTPUT_DIR/$ZIP_NAME" | cut -f1)
    echo "  ✓ Package created: ${GREEN}$ZIP_NAME${NC} (${FILE_SIZE})"
else
    echo -e "  ${RED}✗ Error: Failed to create ZIP file${NC}"
    rm -rf "$TEMP_DIR"
    exit 1
fi

# Step 6: Clean up temporary directory
echo -e "${BLUE}[6/6]${NC} Cleaning up..."
rm -rf "$TEMP_DIR"
echo "  ✓ Temporary files removed"

# Final summary
echo ""
echo -e "${GREEN}========================================${NC}"
echo -e "${GREEN}  ✅ Package Complete!${NC}"
echo -e "${GREEN}========================================${NC}"
echo ""
echo -e "${YELLOW}📦 Output:${NC} $OUTPUT_DIR/$ZIP_NAME"
echo -e "${YELLOW}📏 Size:${NC} $FILE_SIZE"
echo ""
echo -e "${BLUE}📋 Next Steps:${NC}"
echo "  1. Test the extension locally first:"
echo "     - Open chrome://extensions"
echo "     - Enable 'Developer mode'"
echo "     - Click 'Load unpacked' and select the root folder"
echo ""
echo "  2. Once tested, upload to Chrome Web Store:"
echo "     - Go to: https://chrome.google.com/webstore/devconsole"
echo "     - Click 'New Item'"
echo "     - Upload: $OUTPUT_DIR/$ZIP_NAME"
echo ""
echo -e "${GREEN}🚀 Ready for launch!${NC}"
echo ""
