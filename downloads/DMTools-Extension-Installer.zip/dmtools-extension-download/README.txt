# 🎉 Welcome to DMTools Chrome Extension!

Thank you for downloading the DMTools Chrome Extension. This guide will walk you through installing the extension and generating your first AI-powered response.

---

## 📋 What You'll Need

✅ **Google Chrome browser** (download from google.com/chrome if needed)  
✅ **DMTools account** (Pro, Business, or Enterprise plan)  
✅ **5 minutes** of your time

---

## 🚀 STEP 1: Install the Extension

### **Windows Users:**

1. **Extract this ZIP file** to a folder on your desktop
2. **Double-click:** `INSTALL-EXTENSION.bat`
3. Chrome will open automatically to the extensions page
4. Follow the 4 simple steps shown in the installer:
   - Turn ON "Developer mode" (toggle in top-right corner)
   - Click "Load unpacked" button
   - Select the folder where you extracted the files
   - Click "Select Folder"

**Done!** The DMTools icon will appear in your Chrome toolbar.

---

### **Mac/Linux Users:**

1. **Extract this ZIP file** to a folder on your desktop
2. **Double-click:** `install-extension.sh`
3. Chrome will open automatically to the extensions page
4. Follow the 4 simple steps shown in the installer:
   - Turn ON "Developer mode" (toggle in top-right corner)
   - Click "Load unpacked" button
   - Select the folder where you extracted the files
   - Click "Select Folder"

**Done!** The DMTools icon will appear in your Chrome toolbar.

---

## 🔐 STEP 2: Sign In

1. **Click the DMTools icon** in your Chrome toolbar (purple DM logo)
2. **Enter your credentials:**
   - Email address from your DMTools account
   - Password
3. **Click "Login"**

You should see your account dashboard with your plan type.

---

## ✨ STEP 3: Generate Your First Response

Now let's test the extension! We'll use Gmail as an example, but this works on LinkedIn, Twitter, Instagram, Facebook, and more.

### **On Gmail:**

1. **Open Gmail** in Chrome (mail.google.com)
2. **Open any email** you want to reply to
3. **Select the message text** you want to respond to (click and drag to highlight)
4. **Right-click** on the selected text
5. **Choose:** "Capture Message with DMTools"
   - You'll see a small notification confirming the message was captured
6. **Click in the reply box** (where you'd normally type)
7. **Right-click** in the reply box
8. **Choose:** "Generate Reply with DMTools"
9. **Wait 2-5 seconds** - Your AI-generated response will appear!

**That's it!** You can now edit the response, add your personal touch, and send.

---

### **On LinkedIn:**

1. **Open LinkedIn** (linkedin.com)
2. **Go to your messages**
3. **Select the message text** you want to respond to
4. **Right-click** → "Capture Message with DMTools"
5. **Click in the reply box**
6. **Right-click** → "Generate Reply with DMTools"
7. Your AI response appears instantly!

---

### **On Twitter/X:**

1. **Open Twitter/X** (twitter.com or x.com)
2. **Find a tweet** you want to reply to
3. **Select the tweet text**
4. **Right-click** → "Capture Message with DMTools"
5. **Click "Reply" button** under the tweet
6. **Right-click in the reply box** → "Generate Reply with DMTools"
7. Your response is ready!

---

## 🎯 Tips for Best Results

✅ **Select full messages** - The more context, the better the AI response  
✅ **Use your tone settings** - Go to dmtools.fun to set your preferred writing style  
✅ **Edit responses** - Always review and personalize AI suggestions  
✅ **Try different platforms** - Works on 10+ platforms including Instagram, Facebook, TikTok  

---

## ❓ Troubleshooting Q&A

### **Q: The extension icon doesn't appear in Chrome**
**A:** After installation:
1. Click the puzzle piece icon (Extensions) in Chrome toolbar
2. Find "DMTools - AI Reply Assistant"
3. Click the pin icon to make it always visible

---

### **Q: I don't see the right-click menu options**
**A:** Try these fixes:
1. **Refresh the page** (F5 or Cmd+R)
2. **Check you're signed in** - Click the DMTools icon to verify
3. **Reload the extension:**
   - Go to chrome://extensions
   - Find DMTools extension
   - Click the refresh icon

---

### **Q: "Could not load manifest" error during installation**
**A:** Make sure you:
1. Extracted the ZIP file completely (don't run from inside the ZIP)
2. Selected the correct folder (the one containing manifest.json)
3. Have Chrome version 88 or newer

---

### **Q: Login keeps failing**
**A:** Check these:
1. **Use your DMTools.fun credentials** (same email/password)
2. **Verify your plan** - Extension requires Pro, Business, or Enterprise
3. **Check internet connection**
4. **Try logging out and back in** on dmtools.fun first

---

### **Q: "Permission denied" on Mac when running installer**
**A:** Fix permissions:
1. Open Terminal
2. Type: `chmod +x install-extension.sh`
3. Press Enter
4. Now double-click the installer again

---

### **Q: Response generation is slow or fails**
**A:** This could be:
1. **Internet connection** - Check your WiFi
2. **High traffic** - Try again in a few moments
3. **Message too long** - Try selecting a shorter portion
4. **API issue** - Check dmtools.fun/status

---

### **Q: I see a "Developer mode" warning banner**
**A:** This is completely normal! Chrome shows this banner for all extensions loaded from your computer. It's safe to ignore. The warning will disappear once the extension is published to the Chrome Web Store.

---

### **Q: Can I use this on multiple computers?**
**A:** Yes! Just:
1. Download and install on each computer
2. Sign in with the same DMTools account
3. Your settings sync automatically

---

### **Q: Context menus disappeared after Chrome update**
**A:** Sometimes Chrome updates reset extensions:
1. Go to chrome://extensions
2. Turn the DMTools extension OFF then ON
3. Refresh your webpage
4. Context menus should reappear

---

### **Q: The extension uses wrong tone/style**
**A:** Update your settings:
1. Go to dmtools.fun
2. Click "Settings" or "Profile"
3. Update your tone preferences (professional, casual, friendly, etc.)
4. Wait a moment for sync
5. Try generating a new response

---

### **Q: Does this work on mobile Chrome?**
**A:** Unfortunately, Chrome extensions are only supported on desktop/laptop Chrome browsers. Mobile Chrome doesn't support extensions. Use the dmtools.fun web app on mobile devices.

---

### **Q: How do I uninstall the extension?**
**A:** To remove:
1. Go to chrome://extensions
2. Find "DMTools - AI Reply Assistant"
3. Click "Remove"
4. Confirm removal

Your DMTools.fun account remains active - this only removes the extension.

---

### **Q: Can I suggest a new platform/feature?**
**A:** Absolutely! We love feedback:
- Email: support@dmtools.fun
- Website: dmtools.fun/contact
- In-app: Use the feedback button

---

## 📞 Need More Help?

**Website:** https://dmtools.fun  
**Support:** support@dmtools.fun  
**FAQ:** dmtools.fun/faq  
**Status:** dmtools.fun/status

We typically respond within 24 hours!

---

## 🎊 You're All Set!

You now have:
✅ DMTools extension installed  
✅ Signed in to your account  
✅ Generated your first AI response  
✅ Know how to use it on any platform  

**Start saving hours every week with AI-powered responses!**

---

## 🔄 Getting Updates

Right now, you'll need to manually download and install new versions. We'll notify you via email when updates are available.

**Coming soon:** Once we publish to the Chrome Web Store, you'll get automatic updates!

---

## ⭐ Enjoying DMTools?

Help us grow:
- Share with colleagues who reply to lots of messages
- Leave a review on the Chrome Web Store (when available)
- Tag us on social media @dmtools

Thank you for being an early adopter! 🚀

---

**Version:** 1.0.0  
**Last Updated:** November 2025  
**Requires:** Chrome 88+, DMTools Pro/Business/Enterprise account
