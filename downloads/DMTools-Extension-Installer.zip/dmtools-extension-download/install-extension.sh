#!/bin/bash
# ============================================================================
# DMTools Chrome Extension - Automated Installer (Mac/Linux)
# This script automatically opens Chrome extensions page for installation
# ============================================================================

set -e

# Colors
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo ""
echo -e "${BLUE}========================================================================${NC}"
echo -e "${BLUE}              DMTOOLS CHROME EXTENSION INSTALLER${NC}"
echo -e "${BLUE}========================================================================${NC}"
echo ""
echo "This installer will help you set up the DMTools extension in Chrome."
echo ""

# Get script directory
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
EXTENSION_DIR="$SCRIPT_DIR"

echo -e "${BLUE}[1/5]${NC} Checking Chrome installation..."
echo ""

# Detect OS and find Chrome
CHROME_PATH=""
OS_TYPE="$(uname -s)"

case "$OS_TYPE" in
    Darwin*)
        # macOS
        if [ -d "/Applications/Google Chrome.app" ]; then
            CHROME_PATH="/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        elif [ -d "$HOME/Applications/Google Chrome.app" ]; then
            CHROME_PATH="$HOME/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
        fi
        ;;
    Linux*)
        # Linux
        if command -v google-chrome &> /dev/null; then
            CHROME_PATH="google-chrome"
        elif command -v google-chrome-stable &> /dev/null; then
            CHROME_PATH="google-chrome-stable"
        elif command -v chromium-browser &> /dev/null; then
            CHROME_PATH="chromium-browser"
        elif command -v chromium &> /dev/null; then
            CHROME_PATH="chromium"
        fi
        ;;
    *)
        echo -e "${RED}Unsupported operating system: $OS_TYPE${NC}"
        exit 1
        ;;
esac

if [ -z "$CHROME_PATH" ]; then
    echo -e "${RED}ERROR: Chrome not found!${NC}"
    echo ""
    echo "Please install Google Chrome from: https://www.google.com/chrome"
    echo ""
    exit 1
fi

echo -e "   ${GREEN}✓${NC} Chrome found: $CHROME_PATH"
echo ""

echo -e "${BLUE}[2/5]${NC} Checking extension files..."
echo ""

# Verify all required files exist
FILES_OK=true

if [ ! -f "$EXTENSION_DIR/manifest.json" ]; then
    echo -e "   ${RED}✗ manifest.json not found${NC}"
    FILES_OK=false
fi

if [ ! -f "$EXTENSION_DIR/background.js" ]; then
    echo -e "   ${RED}✗ background.js not found${NC}"
    FILES_OK=false
fi

if [ ! -f "$EXTENSION_DIR/content.js" ]; then
    echo -e "   ${RED}✗ content.js not found${NC}"
    FILES_OK=false
fi

if [ ! -f "$EXTENSION_DIR/popup.html" ]; then
    echo -e "   ${RED}✗ popup.html not found${NC}"
    FILES_OK=false
fi

if [ "$FILES_OK" = false ]; then
    echo ""
    echo -e "${RED}ERROR: Extension files are missing!${NC}"
    echo "Please make sure you extracted the files correctly."
    echo ""
    exit 1
fi

echo -e "   ${GREEN}✓${NC} All extension files found"
echo ""

echo -e "${BLUE}[3/5]${NC} Opening Chrome Extensions page..."
echo ""

# Open Chrome extensions page
"$CHROME_PATH" "chrome://extensions" &> /dev/null &

sleep 2

echo -e "${BLUE}[4/5]${NC} ${YELLOW}MANUAL STEPS REQUIRED${NC}"
echo ""
echo "Chrome extensions page is now open. Please follow these steps:"
echo ""
echo -e "   ${GREEN}1.${NC} Find the ${YELLOW}'Developer mode'${NC} toggle in the TOP-RIGHT corner"
echo -e "   ${GREEN}2.${NC} Turn it ${YELLOW}ON${NC} (it should become blue/purple)"
echo -e "   ${GREEN}3.${NC} Click the ${YELLOW}'Load unpacked'${NC} button that appears"
echo -e "   ${GREEN}4.${NC} Select this folder: ${YELLOW}$EXTENSION_DIR${NC}"
echo -e "   ${GREEN}5.${NC} Click ${YELLOW}'Select Folder'${NC}"
echo ""
echo "The extension will then be installed and ready to use!"
echo ""

echo -e "${BLUE}[5/5]${NC} Installation Guide"
echo ""
echo -e "${BLUE}========================================================================${NC}"
echo -e "${BLUE}                      WHAT TO DO NEXT${NC}"
echo -e "${BLUE}========================================================================${NC}"
echo ""
echo "AFTER LOADING THE EXTENSION:"
echo ""
echo -e "${GREEN}1. Sign in to the extension${NC}"
echo "   - Click the DMTools icon in Chrome toolbar"
echo "   - Enter your DMTools.fun credentials"
echo ""
echo -e "${GREEN}2. Test the extension${NC}"
echo "   - Go to Gmail, LinkedIn, or Twitter"
echo "   - Select a message"
echo "   - Right-click and choose 'Capture Message with DMTools'"
echo "   - Click in reply box"
echo "   - Right-click and choose 'Generate Reply with DMTools'"
echo ""
echo -e "${GREEN}3. Pin the extension (optional)${NC}"
echo "   - Click the puzzle icon in Chrome toolbar"
echo "   - Find 'DMTools - AI Reply Assistant'"
echo "   - Click the pin icon to keep it visible"
echo ""
echo -e "${BLUE}========================================================================${NC}"
echo -e "${BLUE}                      TROUBLESHOOTING${NC}"
echo -e "${BLUE}========================================================================${NC}"
echo ""
echo -e "${YELLOW}Problem:${NC} 'Could not load manifest' error"
echo -e "${GREEN}Solution:${NC} Make sure you selected the correct folder containing manifest.json"
echo ""
echo -e "${YELLOW}Problem:${NC} Context menu doesn't appear"
echo -e "${GREEN}Solution:${NC} Refresh the webpage (⌘+R / F5) after installing the extension"
echo ""
echo -e "${YELLOW}Problem:${NC} 'Developer mode' warning banner"
echo -e "${GREEN}Solution:${NC} This is normal for unpacked extensions. Ignore it."
echo ""
echo "Need help? Visit: https://dmtools.fun/contact"
echo ""
echo -e "${BLUE}========================================================================${NC}"
echo ""
echo -e "${GREEN}Installation setup complete!${NC}"
echo ""
