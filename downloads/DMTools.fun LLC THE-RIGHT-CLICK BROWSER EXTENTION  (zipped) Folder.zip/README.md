# DMTools Chrome Extension - Setup Guide

## 🚀 Overview

This Chrome extension allows Pro, Business, and Enterprise subscribers to generate AI-powered responses directly in email compose fields and messaging apps.

## 📋 Features

✅ **Right-click context menu** in any text field
✅ **Instant AI response generation** using your DMTools backend
✅ **Automatic tier verification** (Pro/Business/Enterprise only)
✅ **Works on:** Gmail, Outlook, LinkedIn, Instagram, Facebook, Twitter/X, and more
✅ **Seamless authentication** with existing DMTools accounts

---

## 🎨 STEP 1: Create Icons

You need to create 3 icon files in PNG format:

1. **icon16.png** (16x16 pixels)
2. **icon48.png** (48x48 pixels)
3. **icon128.png** (128x128 pixels)

Place these files in the `icons/` folder.

### Icon Design Suggestions:
- Use your DMTools logo
- Purple/gradient color scheme to match your brand (#667eea to #764ba2)
- Simple, recognizable design
- Should look good on both light and dark backgrounds

### Quick Icon Creation Options:
- **Option 1:** Use Canva or Figma to design
- **Option 2:** Convert existing logo using online tools
- **Option 3:** Use AI image generators (DALL-E, Midjourney)

---

## 🔧 STEP 2: Load Extension in Chrome

1. Open Chrome and go to: `chrome://extensions/`

2. Enable **Developer mode** (toggle in top right)

3. Click **"Load unpacked"**

4. Select the `dmtools-extension` folder

5. Extension should now appear in your Chrome toolbar!

---

## 🧪 STEP 3: Test the Extension

### Test Authentication:
1. Click the extension icon in Chrome toolbar
2. Sign in with your DMTools credentials
3. Verify your plan is displayed correctly

### Test Response Generation:
1. Open Gmail or any email service
2. Click "Compose" or "Reply"
3. Right-click in the message text field
4. Select "✨ Generate Response with DMTools"
5. Watch the AI response appear!

### Test Tier Verification:
- **Pro/Business/Enterprise users:** Should see extension working
- **Free users:** Should see upgrade prompt

---

## 📁 File Structure

```
dmtools-extension/
├── manifest.json          # Extension configuration
├── background.js          # Context menu & API logic
├── content.js            # Page interaction script
├── popup.html            # Extension popup UI
├── popup.js              # Popup authentication logic
├── popup.css             # Popup styling
├── icons/                # Extension icons
│   ├── icon16.png
│   ├── icon48.png
│   └── icon128.png
└── README.md             # This file
```

---

## 🔐 Authentication & Security

### How it works:
1. Users sign in via the extension popup
2. JWT token is stored in `chrome.storage.local`
3. Every API request includes the token in headers
4. Backend verifies token and checks user plan
5. Only Pro/Business/Enterprise users can generate responses

### Allowed Tiers:
- `pro` - Pro Monthly
- `pro_annual` - Pro Annual
- `business` - Business Monthly
- `business_annual` - Business Annual
- `enterprise` - Enterprise Monthly
- `enterprise_annual` - Enterprise Annual

---

## 🌐 Backend Integration

### API Endpoints Used:

**Authentication:**
- `POST /api/user/login` - Sign in
- `GET /api/user/profile` - Get user info & plan

**Response Generation:**
- `POST /api/generate/response` - Generate AI response

### Required Headers:
```javascript
{
  'Authorization': 'Bearer <token>',
  'Content-Type': 'application/json'
}
```

---

## 🚀 Publishing to Chrome Web Store

### Before Publishing:
1. ✅ Test thoroughly on multiple sites
2. ✅ Create proper icons (16, 48, 128)
3. ✅ Add privacy policy URL
4. ✅ Create promotional images (1280x800, 640x400)
5. ✅ Write compelling description

### Publishing Steps:
1. Go to: https://chrome.google.com/webstore/devconsole
2. Pay $5 one-time developer fee (if first time)
3. Click "New Item"
4. Upload extension ZIP file
5. Fill in store listing details
6. Submit for review (takes 1-3 days)

---

## 💡 Marketing Strategy

### Positioning:
- **"The only AI writing tool that works WHERE you work"**
- **"No copy-paste. No tab-switching. Just right-click."**

### Target Messaging:
- Social media managers: "Respond to 100 DMs without leaving Instagram"
- Customer support: "Generate email responses in Gmail instantly"
- Sales teams: "Reply to LinkedIn messages faster"

### Premium Feature Angle:
- Free users see it but can't use it = conversion driver
- Justify higher pricing tiers
- Competitive advantage over other AI tools

---

## 🐛 Troubleshooting

### Extension not showing in context menu:
- Make sure you're right-clicking in an editable field
- Check Chrome Extensions page for errors
- Reload the extension

### "Authentication failed" error:
- Verify backend is running: https://dmtools-backend-production.up.railway.app
- Check if JWT token is valid
- Try logging out and back in

### Response not inserting:
- Check browser console for errors
- Verify the field is truly editable
- Try on Gmail first (most compatible)

### Free users not seeing upgrade prompt:
- Check ALLOWED_TIERS array in background.js
- Verify backend is returning correct plan name
- Check browser console for plan value

---

## 🔄 Future Enhancements

### Phase 2 Features:
- [ ] Read full email thread for better context
- [ ] Multiple tone options (professional, casual, friendly)
- [ ] Custom templates from user's DMTools account
- [ ] Keyboard shortcut (Ctrl+Shift+G)
- [ ] Response preview before inserting
- [ ] Multi-language support
- [ ] Usage analytics

### Phase 3 Features:
- [ ] Smart reply suggestions (3 options)
- [ ] Sentiment analysis of incoming message
- [ ] Automatic draft saving
- [ ] Integration with DMTools CSV exports
- [ ] Team collaboration features

---

## 📊 Analytics to Track

Once live, monitor:
- Daily active users (DAU)
- Responses generated per user
- Conversion rate (free → premium)
- Most-used platforms (Gmail, LinkedIn, etc.)
- Error rates
- User feedback

---

## 🎯 Success Metrics

### Week 1 Goals:
- 100 installs from existing users
- 50+ responses generated daily
- < 5% error rate

### Month 1 Goals:
- 500+ active users
- 10% conversion increase for Pro/Business
- Featured in Chrome Web Store

---

## 📞 Support

For issues or questions:
- Email: support@dmtools.fun
- Website: https://dmtools.fun
- Report bugs via Chrome Web Store reviews

---

## 🎉 You're Ready!

This extension is a **game-changer** for DMTools. No other AI writing tool offers this level of integration.

Your users will love generating responses without ever leaving their inbox.

Let's launch this! 🚀
