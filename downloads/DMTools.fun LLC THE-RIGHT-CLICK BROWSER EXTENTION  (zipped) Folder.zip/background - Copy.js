// DMTools Chrome Extension - Background Script
const API_BASE = 'https://dmtools-backend-production.up.railway.app/api';

// Tiers that can use the extension
const ALLOWED_TIERS = ['pro', 'pro_weekly', 'pro_annual', 'business', 'business_weekly', 'business_annual', 'enterprise', 'enterprise_annual'];

// Store captured message and settings
let capturedMessage = '';
let userSettings = {
  defaultTone: 'friendly',
  context: '',
  platformSettings: {},
  presets: []
};

console.log('DMTools Extension Background Script Loading...');

// Create context menu items
chrome.runtime.onInstalled.addListener(() => {
  console.log('✅ DMTools Extension Installed');
  
  // Menu item 1: Capture selected text
  chrome.contextMenus.create({
    id: 'dmtools-capture',
    title: '📥 Capture message with DMTools',
    contexts: ['selection']
  });
  
  // Menu item 2: Generate response
  chrome.contextMenus.create({
    id: 'dmtools-generate',
    title: '✨ Generate with DMTools',
    contexts: ['editable']
  });
  
  console.log('✅ Context menu items created');
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  console.log('Context menu clicked:', info.menuItemId);
  
  if (info.menuItemId === 'dmtools-capture') {
    await handleCapture(info, tab);
  } else if (info.menuItemId === 'dmtools-generate') {
    await handleGenerate(info, tab);
  }
});

// Step 1: Capture the selected message
async function handleCapture(info, tab) {
  const selectedText = info.selectionText?.trim();
  
  if (!selectedText) {
    showNotification(tab.id, '❌ No text selected', 'Please select some text first');
    return;
  }
  
  capturedMessage = selectedText;
  console.log('📥 Message captured:', capturedMessage.substring(0, 50) + '...');
  
  showNotification(
    tab.id,
    '✅ Message Captured',
    `Captured ${capturedMessage.length} characters. Now right-click in your reply box and choose "Generate with DMTools"`
  );
}

// Step 2: Generate response and insert it
async function handleGenerate(info, tab) {
  console.log('🎯 Generate clicked');
  
  // Check if we have a captured message
  if (!capturedMessage) {
    showNotification(
      tab.id,
      '⚠️ No Message Captured',
      'First, select the incoming message and right-click → "Capture message with DMTools"'
    );
    return;
  }
  
  // Check authentication
  const auth = await checkAuthentication();
  
  if (!auth.authenticated) {
    showNotification(tab.id, '🔒 Sign In Required', 'Please sign in to use DMTools extension');
    return;
  }
  
  if (!auth.isPremium) {
    showNotification(
      tab.id,
      '⭐ Premium Feature',
      `Extension requires Pro, Business, or Enterprise plan. Current plan: ${auth.plan || 'free'}`
    );
    return;
  }
  
  // Show generating notification
  showNotification(tab.id, '⏳ Generating...', 'Creating AI response for you');
  
  try {
    // Detect platform (optional - for platform-specific tones)
    const platform = detectPlatform(tab.url);
    console.log('🌐 Detected platform:', platform);
    
    // Get tone for this platform (or use default)
    const tone = userSettings.platformSettings?.[platform] || userSettings.defaultTone || 'friendly';
    const context = userSettings.context || '';
    
    console.log('🎨 Using tone:', tone);
    console.log('📝 Message to process:', capturedMessage.substring(0, 100));
    
    // Call backend API
    const response = await fetch(`${API_BASE}/generate/single`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${auth.token}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: capturedMessage,
        tone: tone,
        context: context,
        platform: platform
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || 'Failed to generate response');
    }
    
    const data = await response.json();
    const generatedResponse = data.response;
    
    console.log('✅ Response generated:', generatedResponse.substring(0, 50) + '...');
    
    // Send response to content script to insert
    chrome.tabs.sendMessage(tab.id, {
      action: 'insertResponse',
      response: generatedResponse
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('❌ Error sending to content script:', chrome.runtime.lastError.message);
        showNotification(
          tab.id,
          '❌ Insertion Failed',
          'Please refresh the page and try again'
        );
      } else if (response && response.success) {
        console.log('✅ Response inserted successfully');
        // Clear captured message after successful use
        capturedMessage = '';
      } else {
        console.error('❌ Content script reported failure');
        showNotification(
          tab.id,
          '❌ Could Not Insert',
          'Make sure you right-clicked inside the reply box'
        );
      }
    });
    
  } catch (error) {
    console.error('❌ Error generating response:', error);
    showNotification(tab.id, '❌ Error', error.message);
  }
}

// Detect platform from URL
function detectPlatform(url) {
  if (!url) return 'other';
  
  const urlLower = url.toLowerCase();
  
  if (urlLower.includes('mail.google.com')) return 'gmail';
  if (urlLower.includes('outlook.live.com') || urlLower.includes('outlook.office.com')) return 'outlook';
  if (urlLower.includes('linkedin.com')) return 'linkedin';
  if (urlLower.includes('twitter.com') || urlLower.includes('x.com')) return 'twitter';
  if (urlLower.includes('instagram.com')) return 'instagram';
  if (urlLower.includes('facebook.com') || urlLower.includes('messenger.com')) return 'facebook';
  if (urlLower.includes('tiktok.com')) return 'tiktok';
  
  return 'other';
}

// Check authentication and tier
async function checkAuthentication() {
  try {
    const result = await chrome.storage.local.get(['token']);
    const token = result.token;
    
    console.log('Checking authentication, token exists:', !!token);
    
    if (!token) {
      return { authenticated: false, isPremium: false };
    }
    
    // Verify token and get user info
    const response = await fetch(`${API_BASE}/user/profile`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      console.log('Token invalid, removing');
      await chrome.storage.local.remove('token');
      return { authenticated: false, isPremium: false };
    }
    
    const userData = await response.json();
    const userPlan = userData.user?.plan || userData.plan || 'free';
    
    // Check if user has premium tier
    const isPremium = ALLOWED_TIERS.includes(userPlan);
    
    console.log('✅ User authenticated - Plan:', userPlan, 'Is Premium:', isPremium);
    
    // Fetch user settings
    await fetchUserSettings(token);
    
    return {
      authenticated: true,
      isPremium: isPremium,
      token: token,
      plan: userPlan,
      user: userData
    };
    
  } catch (error) {
    console.error('Auth check error:', error);
    return { authenticated: false, isPremium: false };
  }
}

// Fetch user's extension settings from backend
async function fetchUserSettings(token) {
  try {
    const response = await fetch(`${API_BASE}/user/extension-settings`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (response.ok) {
      const data = await response.json();
      if (data.success && data.settings) {
        userSettings = data.settings;
        console.log('✅ User settings loaded:', userSettings);
      }
    }
  } catch (error) {
    console.error('Failed to fetch user settings:', error);
    // Continue with default settings
  }
}

// Show notification in page
function showNotification(tabId, title, message) {
  chrome.tabs.sendMessage(tabId, {
    action: 'showNotification',
    title: title,
    message: message
  }, (response) => {
    if (chrome.runtime.lastError) {
      console.log('Could not show notification:', chrome.runtime.lastError.message);
    }
  });
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'checkAuth') {
    checkAuthentication().then(sendResponse);
    return true;
  }
  
  if (request.action === 'saveToken') {
    chrome.storage.local.set({ token: request.token }, () => {
      console.log('✅ Token saved');
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'logout') {
    chrome.storage.local.remove('token', () => {
      capturedMessage = ''; // Clear captured message on logout
      console.log('✅ Logged out');
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'getCapturedMessage') {
    sendResponse({ message: capturedMessage });
    return true;
  }
  
  if (request.action === 'clearCapturedMessage') {
    capturedMessage = '';
    sendResponse({ success: true });
    return true;
  }
});

// Auto-sync settings every 5 minutes
setInterval(async () => {
  const result = await chrome.storage.local.get(['token']);
  if (result.token) {
    await fetchUserSettings(result.token);
  }
}, 5 * 60 * 1000);

console.log('✅ DMTools background script loaded');