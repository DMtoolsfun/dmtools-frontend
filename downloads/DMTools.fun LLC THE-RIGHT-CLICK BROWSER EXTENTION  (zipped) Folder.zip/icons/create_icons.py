from PIL import Image, ImageDraw, ImageFont
import os

# Create icons with gradient background and DM text
def create_icon(size, filename):
    # Create image with gradient purple background
    img = Image.new('RGB', (size, size), color='#764ba2')
    draw = ImageDraw.Draw(img)
    
    # Draw gradient effect (simple version)
    for i in range(size):
        # Gradient from #667eea to #764ba2
        r = int(102 + (118 - 102) * i / size)
        g = int(126 + (75 - 126) * i / size)
        b = int(234 + (162 - 234) * i / size)
        color = (r, g, b)
        draw.line([(0, i), (size, i)], fill=color)
    
    # Add "DM" text in white
    try:
        # Try to use a nice font
        if size >= 48:
            font_size = int(size * 0.4)
        else:
            font_size = int(size * 0.5)
        
        # Draw white "DM" text
        text = "DM"
        # Calculate text position to center it
        text_bbox = draw.textbbox((0, 0), text)
        text_width = text_bbox[2] - text_bbox[0]
        text_height = text_bbox[3] - text_bbox[1]
        
        # For small icons, just draw a circle
        if size == 16:
            # Draw a small circle
            draw.ellipse([4, 4, 12, 12], fill='white')
        else:
            # Draw text
            x = (size - text_width) // 2 - text_bbox[0]
            y = (size - text_height) // 2 - text_bbox[1]
            draw.text((x, y), text, fill='white')
    except:
        # Fallback: draw a simple shape
        if size >= 48:
            draw.ellipse([size//4, size//4, 3*size//4, 3*size//4], fill='white', outline='#667eea', width=2)
        else:
            draw.ellipse([4, 4, size-4, size-4], fill='white')
    
    # Save
    img.save(filename, 'PNG')
    print(f'Created {filename}')

# Create all three icons
create_icon(16, 'icon16.png')
create_icon(48, 'icon48.png')
create_icon(128, 'icon128.png')

print('\nAll icons created successfully!')
