// DMTools Chrome Extension - Content Script
// Handles text insertion and notifications on web pages

// Track currently focused editable element
let lastFocusedElement = null;

// Track focused editable elements
document.addEventListener('focusin', (e) => {
  if (isEditableElement(e.target)) {
    lastFocusedElement = e.target;
    console.log('📝 Editable field focused:', e.target.tagName);
  }
}, true);

// Track right-clicks on editable elements
document.addEventListener('contextmenu', (e) => {
  if (isEditableElement(e.target)) {
    lastFocusedElement = e.target;
    console.log('📝 Right-clicked on editable field:', e.target.tagName);
  }
}, true);

// Check if element is editable
function isEditableElement(element) {
  if (!element) return false;
  
  // Check for standard form elements
  if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
    return !element.disabled && !element.readOnly;
  }
  
  // Check for contenteditable
  if (element.isContentEditable || element.getAttribute('contenteditable') === 'true') {
    return true;
  }
  
  return false;
}

// Find compose field for inserting text
function findComposeField() {
  // Priority 1: Use the last focused element if it's still in the DOM
  if (lastFocusedElement && document.contains(lastFocusedElement) && isEditableElement(lastFocusedElement)) {
    console.log('✅ Using last focused element');
    return lastFocusedElement;
  }
  
  // Priority 2: Try to find the currently focused element
  const activeElement = document.activeElement;
  if (activeElement && isEditableElement(activeElement)) {
    console.log('✅ Using active element');
    return activeElement;
  }
  
  // Priority 3: Look for any recently focused element
  const allEditableElements = Array.from(document.querySelectorAll('textarea, input, [contenteditable="true"]'));
  for (const element of allEditableElements) {
    if (element === lastFocusedElement || element === document.activeElement) {
      console.log('✅ Found recently focused element');
      return element;
    }
  }
  
  // Priority 4: Search for common compose field selectors
  const selectors = [
    // Gmail
    'div[role="textbox"][g_editable="true"]',
    'div[contenteditable="true"][aria-label*="Message"]',
    'div[contenteditable="true"][role="textbox"]',
    'div.editable[role="textbox"]',
    // Outlook
    'div[aria-label*="Message body"]',
    'div[data-ogsc="Message body"]',
    // LinkedIn
    'div.msg-form__contenteditable',
    'div[contenteditable="true"][role="textbox"]',
    // Twitter/X
    'div[data-testid="tweetTextarea_0"]',
    'div[data-testid="dmComposerTextInput"]',
    // Instagram (web)
    'textarea[placeholder*="Message"]',
    'div[contenteditable="true"][role="textbox"]',
    // Generic
    'textarea[aria-label*="message" i]',
    'textarea[placeholder*="message" i]',
    'textarea[placeholder*="reply" i]',
    'div[contenteditable="true"]'
  ];
  
  for (const selector of selectors) {
    try {
      const element = document.querySelector(selector);
      if (element && isEditableElement(element)) {
        console.log('✅ Found compose field using selector:', selector);
        return element;
      }
    } catch (e) {
      // Invalid selector, skip
    }
  }
  
  console.log('❌ No compose field found');
  return null;
}

// Insert text into element
function insertTextIntoElement(element, text) {
  if (!element) {
    console.error('❌ No element to insert text into');
    return false;
  }
  
  console.log('📝 Inserting text into:', element.tagName, element.className);
  
  try {
    // For standard inputs/textareas
    if (element.tagName === 'TEXTAREA' || element.tagName === 'INPUT') {
      element.value = text;
      
      // Trigger events to notify the page
      element.dispatchEvent(new Event('input', { bubbles: true }));
      element.dispatchEvent(new Event('change', { bubbles: true }));
      element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
      element.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
      
      console.log('✅ Text inserted into input/textarea');
      return true;
    }
    
    // For contenteditable elements (Gmail, LinkedIn, etc.)
    if (element.isContentEditable || element.getAttribute('contenteditable') === 'true') {
      // Method 1: Try setting innerText (cleanest)
      element.innerText = text;
      
      // Method 2: If that doesn't work, try innerHTML with proper formatting
      if (!element.innerText) {
        // Split by newlines and create proper structure
        const lines = text.split('\n');
        element.innerHTML = lines.map(line => {
          const div = document.createElement('div');
          div.textContent = line || '\u200B'; // Zero-width space for empty lines
          return div.outerHTML;
        }).join('');
      }
      
      // Trigger all the events
      element.dispatchEvent(new Event('input', { bubbles: true }));
      element.dispatchEvent(new Event('change', { bubbles: true }));
      element.dispatchEvent(new Event('textInput', { bubbles: true }));
      element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true }));
      element.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
      element.dispatchEvent(new KeyboardEvent('keypress', { bubbles: true }));
      
      // Set focus and move cursor to end
      element.focus();
      
      // Move cursor to end
      const range = document.createRange();
      const sel = window.getSelection();
      
      // Get the last text node
      let lastNode = element;
      while (lastNode.lastChild) {
        lastNode = lastNode.lastChild;
      }
      
      try {
        range.setStart(lastNode, lastNode.textContent?.length || 0);
        range.collapse(true);
        sel.removeAllRanges();
        sel.addRange(range);
      } catch (e) {
        // Cursor positioning failed, but text is inserted
        console.log('⚠️ Cursor positioning failed, but text inserted');
      }
      
      console.log('✅ Text inserted into contenteditable element');
      return true;
    }
    
    console.error('❌ Element is not editable');
    return false;
    
  } catch (error) {
    console.error('❌ Error inserting text:', error);
    return false;
  }
}

// Show notification in page
function showNotification(title, message, type = 'success') {
  // Remove existing notification if any
  const existingNotification = document.getElementById('dmtools-notification');
  if (existingNotification) {
    existingNotification.remove();
  }
  
  // Create notification element
  const notification = document.createElement('div');
  notification.id = 'dmtools-notification';
  notification.style.cssText = `
    position: fixed;
    top: 20px;
    right: 20px;
    background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
    color: white;
    padding: 16px 20px;
    border-radius: 8px;
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1), 0 2px 4px rgba(0, 0, 0, 0.06);
    z-index: 999999;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    font-size: 14px;
    max-width: 400px;
    animation: slideIn 0.3s ease-out;
  `;
  
  notification.innerHTML = `
    <div style="font-weight: 600; margin-bottom: 4px;">${title}</div>
    <div style="opacity: 0.9;">${message}</div>
  `;
  
  // Add animation styles
  const style = document.createElement('style');
  style.textContent = `
    @keyframes slideIn {
      from {
        transform: translateX(400px);
        opacity: 0;
      }
      to {
        transform: translateX(0);
        opacity: 1;
      }
    }
    @keyframes slideOut {
      from {
        transform: translateX(0);
        opacity: 1;
      }
      to {
        transform: translateX(400px);
        opacity: 0;
      }
    }
  `;
  document.head.appendChild(style);
  
  document.body.appendChild(notification);
  
  // Auto-remove after 4 seconds
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease-in';
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 300);
  }, 4000);
}

// Listen for messages from background script
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('📨 Received message:', request.action);
  
  // ✅ FIXED: Changed from 'insertResponse' to 'insertText' to match background.js
  // ✅ FIXED: Changed from 'request.response' to 'request.text' to match background.js
  if (request.action === 'insertText') {
    console.log('📝 Attempting to insert text...');
    
    const composeField = findComposeField();
    
    if (!composeField) {
      console.error('❌ Could not find compose field');
      showNotification(
        '❌ No Text Field Found',
        'Please click in the reply/message box first, then try again.',
        'error'
      );
      sendResponse({ success: false, error: 'No compose field found' });
      return true;
    }
    
    const success = insertTextIntoElement(composeField, request.text);
    
    if (success) {
      console.log('✅ Text inserted successfully');
      showNotification(
        '✅ Response Generated',
        'AI response inserted! Feel free to edit before sending.',
        'success'
      );
      sendResponse({ success: true });
    } else {
      console.error('❌ Failed to insert text');
      showNotification(
        '❌ Insertion Failed',
        'Could not insert text. Try clicking in the compose box first.',
        'error'
      );
      sendResponse({ success: false, error: 'Failed to insert text' });
    }
    
    return true; // Keep message channel open for async response
  }
  
  if (request.action === 'showNotification') {
    showNotification(request.title, request.message, request.type || 'info');
    sendResponse({ success: true });
    return true;
  }
  
  return false;
});

console.log('✅ DMTools content script ready - FIXED VERSION');