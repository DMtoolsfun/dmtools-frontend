// DMTools Chrome Extension - Popup Script
// Handles authentication and user interface

const API_BASE = 'https://dmtools-backend-production.up.railway.app/api';
const ALLOWED_TIERS = ['pro', 'pro_annual', 'business', 'business_annual', 'enterprise', 'enterprise_annual'];

// DOM Elements
const loginScreen = document.getElementById('loginScreen');
const dashboardScreen = document.getElementById('dashboardScreen');
const loginForm = document.getElementById('loginForm');
const loginError = document.getElementById('loginError');
const userEmail = document.getElementById('userEmail');
const userPlan = document.getElementById('userPlan');
const premiumStatus = document.getElementById('premiumStatus');
const refreshBtn = document.getElementById('refreshBtn');
const logoutBtn = document.getElementById('logoutBtn');

// Check authentication on load
document.addEventListener('DOMContentLoaded', async () => {
  const { token } = await chrome.storage.local.get('token');
  
  if (token) {
    await loadDashboard();
  } else {
    showLoginScreen();
  }
});

// Handle login form submission
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  
  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;
  
  try {
    loginError.style.display = 'none';
    const submitBtn = loginForm.querySelector('button');
    submitBtn.textContent = 'Signing in...';
    submitBtn.disabled = true;
    
    console.log('Attempting login to:', `${API_BASE}/user/login`);
    console.log('Email:', email);
    
    const response = await fetch(`${API_BASE}/user/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, password })
    });
    
    console.log('Response status:', response.status);
    
    const data = await response.json();
    console.log('Response data:', data);
    
    if (!response.ok) {
      throw new Error(data.error || 'Login failed');
    }
    
    // Store token
    await chrome.storage.local.set({ token: data.token });
    
    console.log('Login successful, token stored');
    
    // Load dashboard
    await loadDashboard();
    
  } catch (error) {
    console.error('Login error:', error);
    loginError.textContent = error.message;
    loginError.style.display = 'block';
    
    const submitBtn = loginForm.querySelector('button');
    submitBtn.textContent = 'Sign In';
    submitBtn.disabled = false;
  }
});

// Load dashboard with user info
async function loadDashboard() {
  try {
    const { token } = await chrome.storage.local.get('token');
    
    if (!token) {
      showLoginScreen();
      return;
    }
    
    const response = await fetch(`${API_BASE}/user/profile`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      throw new Error('Failed to load profile');
    }
    
    const data = await response.json();
    const user = data.user || data;
    const plan = user.plan || 'free';
    
    // Update UI
    userEmail.textContent = user.email;
    
    // Format plan name
    const planNames = {
      'free': 'Free Plan',
      'starter_weekly': 'Starter Weekly',
      'starter': 'Starter Monthly',
      'pro': 'Pro Monthly',
      'pro_annual': 'Pro Annual',
      'business': 'Business Monthly',
      'business_annual': 'Business Annual',
      'enterprise': 'Enterprise Monthly',
      'enterprise_annual': 'Enterprise Annual'
    };
    
    userPlan.textContent = planNames[plan] || plan;
    
    // Check if user has premium access
    const isPremium = ALLOWED_TIERS.includes(plan);
    
    if (isPremium) {
      premiumStatus.innerHTML = `
        <div class="status-success">
          <span class="status-icon">✅</span>
          <div>
            <h3>Extension Access Active</h3>
            <p>You can use AI response generation in any text field</p>
          </div>
        </div>
      `;
    } else {
      premiumStatus.innerHTML = `
        <div class="status-warning">
          <span class="status-icon">🔒</span>
          <div>
            <h3>Premium Feature</h3>
            <p>Upgrade to Pro, Business, or Enterprise to use the Chrome Extension</p>
            <a href="https://dmtools.fun" target="_blank" class="btn-upgrade">
              Upgrade Now
            </a>
          </div>
        </div>
      `;
    }
    
    // Show dashboard
    showDashboardScreen();
    
  } catch (error) {
    console.error('Dashboard load error:', error);
    await chrome.storage.local.remove('token');
    showLoginScreen();
  }
}

// Refresh status
refreshBtn.addEventListener('click', async () => {
  refreshBtn.textContent = 'Refreshing...';
  refreshBtn.disabled = true;
  
  await loadDashboard();
  
  refreshBtn.textContent = 'Refresh Status';
  refreshBtn.disabled = false;
});

// Logout
logoutBtn.addEventListener('click', async () => {
  await chrome.storage.local.remove('token');
  loginForm.reset();
  showLoginScreen();
});

// Screen navigation
function showLoginScreen() {
  loginScreen.style.display = 'block';
  dashboardScreen.style.display = 'none';
}

function showDashboardScreen() {
  loginScreen.style.display = 'none';
  dashboardScreen.style.display = 'block';
}
