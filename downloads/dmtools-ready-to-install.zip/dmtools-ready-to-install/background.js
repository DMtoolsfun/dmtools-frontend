// DMTools Chrome Extension - Background Service Worker
// PERSONALIZED VERSION with user settings, platform detection, and preset support

const API_BASE = 'https://dmtools-backend-production.up.railway.app/api';
const ALLOWED_TIERS = ['pro', 'business', 'enterprise', 'pro_annual', 'business_annual', 'enterprise_annual'];

// Keepalive mechanism
let keepaliveInterval;
let settingsSyncInterval;

function startKeepalive() {
  keepaliveInterval = setInterval(() => {
    chrome.runtime.getPlatformInfo(() => {});
  }, 20000);
  console.log('Keepalive started');
}

function stopKeepalive() {
  if (keepaliveInterval) {
    clearInterval(keepaliveInterval);
    console.log('Keepalive stopped');
  }
}

startKeepalive();

// Settings sync - refresh user settings every 5 minutes
function startSettingsSync() {
  settingsSyncInterval = setInterval(async () => {
    const result = await chrome.storage.local.get(['token']);
    if (result.token) {
      console.log('Syncing user settings...');
      await fetchUserSettings(result.token);
    }
  }, 5 * 60 * 1000); // 5 minutes
  console.log('Settings sync started (5 min interval)');
}

function stopSettingsSync() {
  if (settingsSyncInterval) {
    clearInterval(settingsSyncInterval);
    console.log('Settings sync stopped');
  }
}

startSettingsSync();

// Platform detection function
function detectPlatform(url) {
  if (!url) return 'other';
  
  const urlLower = url.toLowerCase();
  
  // Email platforms
  if (urlLower.includes('mail.google.com')) return 'gmail';
  if (urlLower.includes('outlook.live.com') || urlLower.includes('outlook.office')) return 'outlook';
  if (urlLower.includes('mail.yahoo.com')) return 'yahoo';

  // Social media platforms
  if (urlLower.includes('linkedin.com')) return 'linkedin';
  if (urlLower.includes('twitter.com') || urlLower.includes('x.com')) return 'twitter';
  if (urlLower.includes('instagram.com')) return 'instagram';
  if (urlLower.includes('facebook.com') || urlLower.includes('messenger.com')) return 'facebook';
  if (urlLower.includes('tiktok.com')) return 'tiktok';
  
  // Messaging platforms
  if (urlLower.includes('slack.com')) return 'slack';
  if (urlLower.includes('discord.com')) return 'discord';
  if (urlLower.includes('telegram.org') || urlLower.includes('web.telegram.org')) return 'telegram';
  
  // Default
  return 'other';
}

// Fetch user settings from backend
async function fetchUserSettings(token) {
  try {
    const response = await fetch(`${API_BASE}/user/extension-settings`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      console.error('Failed to fetch settings:', response.status);
      return null;
    }
    
    const data = await response.json();
    
    if (data.success && data.settings) {
      // Save to storage
      await chrome.storage.local.set({ 
        userSettings: data.settings,
        settingsLastSync: Date.now()
      });
      
      console.log('User settings synced:', {
        defaultTone: data.settings.defaultTone,
        hasContext: !!data.settings.context,
        platforms: Object.keys(data.settings.platformSettings || {}),
        presetCount: data.settings.presets?.length || 0
      });
      
      return data.settings;
    }
    
    return null;
  } catch (error) {
    console.error('Settings fetch error:', error);
    return null;
  }
}

// Create context menus
chrome.contextMenus.removeAll(() => {
  chrome.contextMenus.create({
    id: 'dmtools-capture',
    title: 'Capture Message with DMTools',
    contexts: ['selection']
  });
  
  chrome.contextMenus.create({
    id: 'dmtools-generate',
    title: 'Generate Reply with DMTools',
    contexts: ['editable']
  });
  
  // Add preset submenu when available
  chrome.contextMenus.create({
    id: 'dmtools-use-preset',
    title: 'Use Saved Preset',
    contexts: ['editable']
  });
  
  console.log('Context menus created');
});

chrome.runtime.onInstalled.addListener(() => {
  console.log('Extension installed/updated');
});

// Handle context menu clicks
chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  console.log('Context menu clicked:', info.menuItemId);
  
  // ========================================
  // STEP 1: CAPTURE INCOMING MESSAGE
  // ========================================
  if (info.menuItemId === 'dmtools-capture') {
    console.log('Capture Message clicked');
    
    const selectedText = info.selectionText || '';
    
    if (!selectedText || selectedText.trim().length < 5) {
      console.log('Text too short:', selectedText.length, 'characters');
      showNotification(tab.id, 'Text too short', 'Select at least 5 characters');
      return;
    }
    
    console.log('Captured message:', selectedText.substring(0, 100) + '...');
    
    // Detect platform for context
    const platform = detectPlatform(tab.url);
    console.log('Platform detected:', platform);
    
    await chrome.storage.local.set({ 
      capturedMessage: selectedText,
      capturedAt: Date.now(),
      capturedPlatform: platform,
      capturedUrl: tab.url
    });
    
    console.log('Message saved to storage');
    showNotification(tab.id, 'Message captured!', 'Now right-click in reply field and generate');
  }
  
  // ========================================
  // STEP 2: GENERATE REPLY
  // ========================================
  if (info.menuItemId === 'dmtools-generate') {
    console.log('Generate Reply clicked');
    
    // Check authentication
    const authStatus = await checkAuthentication();
    
    if (!authStatus.authenticated) {
      console.log('User not authenticated');
      showNotification(tab.id, 'Please sign in first', 'Click the DMTools icon to sign in');
      return;
    }
    
    if (!authStatus.isPremium) {
      console.log('User not premium, plan:', authStatus.plan || 'none');
      showNotification(tab.id, 'Premium Feature', 'Upgrade to Pro, Business, or Enterprise');
      return;
    }
    
    // Get captured message and user settings
    const storage = await chrome.storage.local.get([
      'capturedMessage', 
      'capturedAt', 
      'capturedPlatform',
      'userSettings',
      'selectedPresetId'
    ]);
    
    const capturedMessage = storage.capturedMessage;
    const capturedAt = storage.capturedAt;
    const capturedPlatform = storage.capturedPlatform || 'other';
    const userSettings = storage.userSettings || {};
    const selectedPresetId = storage.selectedPresetId;
    
    console.log('Captured message exists:', !!capturedMessage);
    console.log('User settings loaded:', !!userSettings.defaultTone);
    
    if (!capturedMessage) {
      console.log('No message captured');
      showNotification(tab.id, 'No message captured', 'First select text and choose "Capture Message"');
      return;
    }
    
    // Check if captured message is recent (10 minutes)
    const tenMinutesAgo = Date.now() - (10 * 60 * 1000);
    if (capturedAt < tenMinutesAgo) {
      console.log('Captured message expired');
      showNotification(tab.id, 'Message expired', 'Please capture the message again');
      await chrome.storage.local.remove(['capturedMessage', 'capturedAt', 'capturedPlatform']);
      return;
    }
    
    // Detect current platform (might be different from capture platform)
    const currentPlatform = detectPlatform(tab.url);
    console.log('Current platform:', currentPlatform);
    
    // Determine tone to use (platform-specific > default > fallback)
    const platformTone = userSettings.platformSettings?.[currentPlatform];
    const defaultTone = userSettings.defaultTone;
    const tone = platformTone || defaultTone || 'friendly';
    
    console.log('Using tone:', tone, {
      platformSpecific: !!platformTone,
      fromDefaults: !platformTone && !!defaultTone,
      fallback: !platformTone && !defaultTone
    });
    
    // Check if user selected a preset
    let responseToUse = null;
    if (selectedPresetId && userSettings.presets) {
      const preset = userSettings.presets.find(p => p.id === selectedPresetId);
      if (preset) {
        console.log('Using preset:', preset.name);
        responseToUse = preset.response;
      }
    }
    
    console.log('Generating response with personalized settings');
    showNotification(tab.id, 'Generating response...', `Using ${tone} tone for ${currentPlatform}`);
    
    try {
      // If using preset, insert it directly
      if (responseToUse) {
        console.log('Using saved preset response');
        
        chrome.tabs.sendMessage(tab.id, {
          action: 'insertText',
          text: responseToUse
        }, (response) => {
          if (chrome.runtime.lastError) {
            showNotification(tab.id, 'Preset ready!', 'Click in field and paste (Ctrl+V)');
          } else {
            showNotification(tab.id, 'Preset inserted!', 'Review and edit before sending');
          }
        });
        
        // Clear captured message and selected preset
        await chrome.storage.local.remove(['capturedMessage', 'capturedAt', 'capturedPlatform', 'selectedPresetId']);
        return;
      }
      
      // Generate AI response with user context
      console.log('Calling API:', `${API_BASE}/extension/generate`);
      
      const requestBody = {
        message: capturedMessage,
        tone: tone,                           // User's preferred tone
        context: userSettings.context || '',  // User's custom context
        platform: currentPlatform             // Detected platform
      };
      
      console.log('Request body:', {
        messageLength: capturedMessage.length,
        tone: requestBody.tone,
        hasContext: !!requestBody.context,
        platform: requestBody.platform
      });
      
      const response = await fetch(`${API_BASE}/extension/generate`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${authStatus.token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(requestBody)
      });
      
      console.log('API response status:', response.status);
      
      if (!response.ok) {
        const errorData = await response.json();
        console.error('API error:, errorData');
        throw new Error(errorData.error || errorData.message || 'Failed to generate response');
      }
      
      const data = await response.json();
      const generatedResponse = data.response || data.generated_response;
      
      if (!generatedResponse) {
        console.error('No response in API data');
        throw new Error('No response generated');
      }
      
      console.log('Response generated successfully');
      console.log('Response preview:', generatedResponse.substring(0, 100) + '...');
      
      // Insert response into active element
      chrome.tabs.sendMessage(tab.id, {
        action: 'insertText',
        text: generatedResponse
      }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('Error sending message:', chrome.runtime.lastError);
          showNotification(tab.id, 'Response generated!', 'Click in field and paste (Ctrl+V)');
        } else {
          console.log('Response inserted into page');
          showNotification(tab.id, 'Response inserted!', 'Review and edit before sending');
          
          // Clear captured message
          chrome.storage.local.remove(['capturedMessage', 'capturedAt', 'capturedPlatform']);
        }
      });
      
    } catch (error) {
      console.error('Error generating response:', error);
      showNotification(tab.id, 'Error', error.message);
    }
  }
  
  // ========================================
  // STEP 3: USE SAVED PRESET
  // ========================================
  if (info.menuItemId === 'dmtools-use-preset') {
    console.log('Use Preset clicked');
    
    // Open popup to preset selector
    showNotification(tab.id, 'Open Extension', 'Click the DMTools icon to select a preset');
  }
});

// Check authentication and fetch settings
async function checkAuthentication() {
  try {
    const result = await chrome.storage.local.get(['token']);
    const token = result.token;
    
    console.log('Checking authentication, token exists:', !!token);
    
    if (!token) {
      return { authenticated: false, isPremium: false };
    }
    
    // Verify token and get user info
    const response = await fetch(`${API_BASE}/user/profile`, {
      headers: {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (!response.ok) {
      console.log('Token invalid, removing. Status:', response.status);
      await chrome.storage.local.remove('token');
      stopSettingsSync();
      return { authenticated: false, isPremium: false };
    }
    
    const userData = await response.json();
    const userPlan = userData.user?.plan || userData.plan || 'free';
    const isPremium = ALLOWED_TIERS.includes(userPlan);
    
    console.log('User authenticated - Plan:', userPlan, 'Is Premium:', isPremium);
    
    // Fetch user settings if we don't have them
    const settingsResult = await chrome.storage.local.get(['userSettings', 'settingsLastSync']);
    const fiveMinutesAgo = Date.now() - (5 * 60 * 1000);
    
    if (!settingsResult.userSettings || !settingsResult.settingsLastSync || settingsResult.settingsLastSync < fiveMinutesAgo) {
      console.log('Fetching fresh user settings...');
      await fetchUserSettings(token);
    }
    
    return {
      authenticated: true,
      isPremium: isPremium,
      token: token,
      plan: userPlan,
      user: userData
    };
    
  } catch (error) {
    console.error('Auth check error:', error);
    return { authenticated: false, isPremium: false };
  }
}

// Show notification in page
function showNotification(tabId, title, message) {
  chrome.tabs.sendMessage(tabId, {
    action: 'showNotification',
    title: title,
    message: message
  }, (response) => {
    if (chrome.runtime.lastError) {
      console.log('Could not show notification:', chrome.runtime.lastError.message);
    }
  });
}

// Listen for messages from popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('Message received:', request.action);
  
  if (request.action === 'checkAuth') {
    checkAuthentication().then(sendResponse);
    return true;
  }
  
  if (request.action === 'saveToken') {
    chrome.storage.local.set({ token: request.token }, async () => {
      console.log('Token saved');
      // Fetch settings immediately after login
      await fetchUserSettings(request.token);
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'logout') {
    chrome.storage.local.remove(['token', 'capturedMessage', 'capturedAt', 'userSettings', 'selectedPresetId'], () => {
      console.log('Logged out');
      stopSettingsSync();
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'getCapturedMessage') {
    chrome.storage.local.get(['capturedMessage', 'capturedAt', 'capturedPlatform'], (result) => {
      sendResponse({
        hasCaptured: !!result.capturedMessage,
        message: result.capturedMessage,
        capturedAt: result.capturedAt,
        platform: result.capturedPlatform
      });
    });
    return true;
  }
  
  if (request.action === 'getUserSettings') {
    chrome.storage.local.get(['userSettings'], (result) => {
      sendResponse({
        settings: result.userSettings || null
      });
    });
    return true;
  }
  
  if (request.action === 'selectPreset') {
    chrome.storage.local.set({ selectedPresetId: request.presetId }, () => {
      console.log('Preset selected:', request.presetId);
      sendResponse({ success: true });
    });
    return true;
  }
  
  if (request.action === 'refreshSettings') {
    chrome.storage.local.get(['token'], async (result) => {
      if (result.token) {
        const settings = await fetchUserSettings(result.token);
        sendResponse({ success: true, settings: settings });
      } else {
        sendResponse({ success: false, error: 'Not authenticated' });
      }
    });
    return true;
  }
});

console.log('DMTools background script loaded - PERSONALIZED VERSION');
console.log('Service worker active with settings sync');
